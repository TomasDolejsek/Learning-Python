input('Print x and y: ')
int(input())
print('Another num:')
int(input())
