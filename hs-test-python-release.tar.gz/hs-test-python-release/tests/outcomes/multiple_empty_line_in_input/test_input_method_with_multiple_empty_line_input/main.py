i = 1

while True:
    inp = input()
    if inp == '':
        print('empty')
    else:
        print(inp)
    i += 1
