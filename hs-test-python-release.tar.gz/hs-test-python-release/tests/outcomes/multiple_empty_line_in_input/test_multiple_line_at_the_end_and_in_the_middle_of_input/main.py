i = 1

while True:
    inp = input()
    if inp == '':
        print('Empty line')
    else:
        print(inp)
    print(f"Input line number {i}")
    i += 1
