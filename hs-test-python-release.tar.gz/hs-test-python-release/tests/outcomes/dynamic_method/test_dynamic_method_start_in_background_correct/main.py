from time import sleep

print("Server started!")
sleep(0.5)
print("S1")
