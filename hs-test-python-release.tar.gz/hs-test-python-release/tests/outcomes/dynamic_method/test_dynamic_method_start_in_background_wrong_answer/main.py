from time import sleep

print("Server started!")
sleep(0.1)
print("S1")
sleep(0.1)
print("S2")
sleep(0.1)
print("S3")
sleep(100)
print("S4")
