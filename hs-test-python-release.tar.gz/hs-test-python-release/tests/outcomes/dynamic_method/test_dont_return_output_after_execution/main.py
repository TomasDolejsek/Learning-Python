print("Initial text")
input()

print("1 to 2")
input()

print("2 to 3")
input()

print("3 to 4")
input()
