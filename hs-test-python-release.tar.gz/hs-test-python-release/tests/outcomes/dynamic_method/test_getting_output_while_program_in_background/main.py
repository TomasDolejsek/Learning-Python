from time import sleep

while True:
    sleep(0.1)
    print("Test")
