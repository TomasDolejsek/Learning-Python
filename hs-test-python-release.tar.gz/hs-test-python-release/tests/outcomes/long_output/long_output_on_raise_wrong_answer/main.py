for i in range(600):
    print(f"A {i} line")
