print('2050')
