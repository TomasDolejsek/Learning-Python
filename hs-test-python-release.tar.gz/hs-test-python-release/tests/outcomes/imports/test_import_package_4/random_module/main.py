from .in1.in2.main2 import x
from .in1.file import y
print(x + y)
