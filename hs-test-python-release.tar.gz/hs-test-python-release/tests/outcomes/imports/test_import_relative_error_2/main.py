from .main2 import y
print(x)
