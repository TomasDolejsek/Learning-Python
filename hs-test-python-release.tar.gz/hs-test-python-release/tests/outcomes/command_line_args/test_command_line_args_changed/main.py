import sys

sys.argv[0] = None
