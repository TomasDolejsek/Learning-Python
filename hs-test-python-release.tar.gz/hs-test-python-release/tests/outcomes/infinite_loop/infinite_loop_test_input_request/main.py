
while True:
    print("Long Line Long Line Long Line")
    try:
        print(input())
    except Exception as ex:
        print(ex)
