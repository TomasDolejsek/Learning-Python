while True:
    print("Line")
