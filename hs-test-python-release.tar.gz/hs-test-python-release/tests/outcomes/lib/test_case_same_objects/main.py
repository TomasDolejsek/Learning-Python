print('Hello')
print(input())
print(input())
print(input())
