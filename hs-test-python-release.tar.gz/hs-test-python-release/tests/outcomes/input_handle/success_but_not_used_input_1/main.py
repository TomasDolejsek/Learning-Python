first_line = int(input())
print(first_line)
if first_line != 1:
    second_line = input()
    print(second_line)
