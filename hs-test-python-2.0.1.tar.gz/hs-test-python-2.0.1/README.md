# hs-test-python
It is a small framework that simplifies testing educational projects for [Hyperskill](https://hyperskill.org).
