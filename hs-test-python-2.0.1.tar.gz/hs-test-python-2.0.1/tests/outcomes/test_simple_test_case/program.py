n = input()
print(n)
print(n)
