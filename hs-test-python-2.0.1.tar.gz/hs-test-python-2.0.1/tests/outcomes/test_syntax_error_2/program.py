print(12 23)
