from time import sleep
sleep(int(input()) / 1000)
