file = open('in.txt')
print(file.read(2))
