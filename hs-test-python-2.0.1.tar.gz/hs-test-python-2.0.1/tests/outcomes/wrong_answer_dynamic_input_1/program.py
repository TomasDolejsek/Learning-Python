print('1')
input()
