print(1)
print(input())
